fx_version 'adamant'

game 'gta5'

client_scripts {
	'dependencies/menu.lua',
	'client.lua'
}

server_scripts {
    'server.lua'
}
